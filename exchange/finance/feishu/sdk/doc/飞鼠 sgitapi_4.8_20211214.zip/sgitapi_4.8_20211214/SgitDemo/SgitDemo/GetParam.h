#ifndef GET_PARAM_H_DQK_20151229
#define GET_PARAM_H_DQK_20151229

#include "SgitFtdcUserApiStruct.h"
#include "SgitFtdcUserApiDataType.h"

int GetIpField(char* pTradeIp,char* pQuotIp);
int GetLoginField(fstech::CThostFtdcReqUserLoginField& reqLoginField);
int GetOrderInsertField(fstech::CThostFtdcInputOrderField& ReqOrderField);
int WriteTradecode(fstech::CThostFtdcTradingCodeField* pTradingCodeField);

#endif