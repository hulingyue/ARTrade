#include "log.h"
using namespace SgitDemo_log;

//ofstream CLogApi::fout;
FILE* CLogApi::pf = 0;
LogMutex CLogApi::log_mutex;

bool CLogApi::Init(char* szpath)
{
	char sDate[20];
	char sTime[20];
#ifdef _WIN32	
	SYSTEMTIME systm;
	GetLocalTime(&systm);
	sprintf(sDate,"%4d-%1d-%1d",systm.wYear,systm.wMonth,systm.wDay);
	sprintf(sTime,"%02d_%02d_%02d",systm.wHour,systm.wMinute,systm.wSecond/*,systm.wMilliseconds*/);	
#else
	struct timeval CurrentTime;
	struct tm *_tx;
	gettimeofday(&CurrentTime, NULL);
	_tx = localtime(&CurrentTime.tv_sec);
	int iUSec = CurrentTime.tv_usec;
	sprintf(sDate,"%4d-%1d-%1d",_tx->tm_year+1900,_tx->tm_mon+1,_tx->tm_mday);
	sprintf(sTime,"%02d_%02d_%02d",_tx->tm_hour,_tx->tm_min,_tx->tm_sec/*,iUSec*/);
#endif
	
	char szFile[256];
	sprintf(szFile,"%slog%s_%s.log",szpath,sDate,sTime);
	//char*p = "log20150812.log";
	log_mutex.lock();
	//fout.open(szFile);
	if(0 == pf)
		pf = fopen(szFile,"w+");
	//if(false == fout.good())
	if(0 == pf)
	{
		printf("�����ļ�[%s]ʧ��\n",szFile);
		log_mutex.unlock();
		return false;
	}
	fprintf(pf,"********************************************************************\n");
	fprintf(pf,"**log at time:%s\n",sTime);
	fprintf(pf,"********************************************************************\n");
	//fout<<"**log at time:"<<tmp<<endl;
	//fout<<"********************************************************************";
	log_mutex.unlock();
	return true;
}
	

CLogApi::CLogApi(char* szpath)
{
	if(0 == CLogApi::pf)
		Init(szpath);
	CLogApi::log_mutex.lock();
}
CLogApi::~CLogApi()
{
	if(NULL != pf)
		fflush(pf);
	CLogApi::log_mutex.unlock();
}

CLogApi& CLogApi::operator << (bool value)
{
	if(0 != pf )
		fprintf(pf,"%s",value ? "true" : "false");
	return *this;
}

CLogApi& CLogApi::operator << (char* value)
{
	if(0 != pf )
		fprintf(pf,"%s", 0 != value ? value : "null");
	return *this;
}

CLogApi& CLogApi::operator << (const char*value)
{
	if(0 != pf )
		fprintf(pf,"%s",0 != value ? value : "null");
	return *this;
}

CLogApi& CLogApi::operator << (char value)
{
	if(0 != pf )
		fprintf(pf,"%c",value);
	return *this;
}

CLogApi& CLogApi::operator << (unsigned char value)
{
	if(0 != pf )
		fprintf(pf,"%c",value);
	return *this;
}

CLogApi& CLogApi::operator << (short value)
{
	if(0 != pf )
		fprintf(pf,"%d",value);
	return *this;
}

CLogApi& CLogApi::operator << (unsigned short value)
{
	if(0 != pf )
		fprintf(pf,"%d",value);
	return *this;
}

CLogApi& CLogApi::operator << (int value)
{
	if(0 != pf )
		fprintf(pf,"%d",value);
	return *this;
}

CLogApi& CLogApi::operator << (unsigned int value)
{
	if(0 != pf )
		fprintf(pf,"%d",value);
	return *this;
}

CLogApi& CLogApi::operator << (long value)
{
	if(0 != pf )
		fprintf(pf,"%ld",value);
	return *this;
}

CLogApi& CLogApi::operator << (unsigned long value)
{
	if(0 != pf )
		fprintf(pf,"%ld",value);
	return *this;
}

CLogApi& CLogApi::operator << (long long value)
{
	if(0 != pf )
		fprintf(pf,"%ld",value);
	return *this;
}

CLogApi& CLogApi::operator << (double value)
{
	if(0 != pf )
		fprintf(pf,"%lf",value);
	return *this;
}

CLogApi& CLogApi::operator << (float value)
{
	if(0 != pf )
		fprintf(pf,"%f",value);
	return *this;
}

CLogApi& CLogApi::operator << (BEFLAG value)
{
	/*if(LOG_BEGIN == value)
	{
	log_mutex.lock();
	be_flag = LOG_BEGIN;
	time_t t = time(0); 
	char tmp[64]; 
	memset(tmp,0,sizeof(tmp));
	strftime( tmp, sizeof(tmp), "[%Y%m%d %H-%M-%S] ",localtime(&t) ); 
	fout<<tmp;
	}
	else
	{
	fout<<std::endl;
	fout.flush();
	be_flag = LOG_END;
	log_mutex.lock();
	}*/
	return *this;
}