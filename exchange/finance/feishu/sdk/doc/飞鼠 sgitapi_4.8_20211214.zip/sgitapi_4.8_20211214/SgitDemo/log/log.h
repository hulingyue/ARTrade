#ifndef _LOGAPI_H_DQK_20151229
#define _LOGAPI_H_DQK_20151229

#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifndef _WIN32
	#include<sys/time.h>
	#include <unistd.h>  
	#include <pthread.h> 
#else
	#include <Windows.h>
#endif

namespace SgitDemo_log
{
	enum BEFLAG
	{
		LOG_BEGIN=0,
		LOG_END=1
	};

	class LogMutex
	{
#ifndef _WIN32
	public:
		LogMutex(){m_mutex = PTHREAD_MUTEX_INITIALIZER;};
		~LogMutex(){ pthread_mutex_destroy(&m_mutex);}
		void lock(){pthread_mutex_lock(&m_mutex);};
		void unlock(){pthread_mutex_unlock(&m_mutex);};

	private:
		pthread_mutex_t m_mutex;
#else
	public:
		LogMutex(){InitializeCriticalSectionAndSpinCount(&m_mutex,100);};
		~LogMutex(){ DeleteCriticalSection(&m_mutex);}
		void lock(){EnterCriticalSection(&m_mutex);};
		void unlock(){LeaveCriticalSection(&m_mutex);};

	private:
		CRITICAL_SECTION m_mutex;
#endif
	};

	class CLogApi
	{
	public:
		CLogApi(char* szpath = "./Log/");
		~CLogApi();
		CLogApi& operator << (bool value);
		CLogApi& operator << (char* value);
		CLogApi& operator << (const char*value);
		CLogApi& operator << (char value);
		CLogApi& operator << (unsigned char value);
		CLogApi& operator << (short value);
		CLogApi& operator << (unsigned short value);
		CLogApi& operator << (int value);
		CLogApi& operator << (unsigned int value);
		CLogApi& operator << (long value);
		CLogApi& operator << (unsigned long value);
		CLogApi& operator << (long long value);
		CLogApi& operator << (double value);
		CLogApi& operator << (float value);

		CLogApi& operator << (BEFLAG value);

		static bool Init(char* szpath = "./");
		static void Log_close(){log_mutex.lock();if(NULL != pf)fclose(pf);log_mutex.unlock();};
	private:
		static FILE *pf;
		static LogMutex log_mutex;
	};
	
}
//#define LOG dqk_log::CLogApi log;log<<LOG_BEGIN<<"("<<__FILE__<<__LINE__<<") "
#endif

