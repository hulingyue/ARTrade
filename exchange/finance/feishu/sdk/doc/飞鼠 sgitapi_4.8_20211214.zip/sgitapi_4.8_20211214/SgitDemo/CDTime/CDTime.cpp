#include "CDTime.h"

TTimeList_map gtime_map;
LGHRTimer_d hrTime;
