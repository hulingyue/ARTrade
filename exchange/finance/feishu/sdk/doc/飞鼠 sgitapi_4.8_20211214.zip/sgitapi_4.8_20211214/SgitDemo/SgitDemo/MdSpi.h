#ifndef _SGITMDSPI_H_DQK_20160602
#define _SGITMDSPI_H_DQK_20160602
#include "SgitFtdcMdApi.h"

using namespace fstech;
class CMdSpi:public  CThostFtdcMdSpi
{
public:
	CMdSpi(CThostFtdcMdApi* pMdApi);
	~CMdSpi();

public:
	virtual void OnFrontConnected();
	virtual void OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast) ;
	virtual void OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData) ;
	//���ӽ�������
	virtual void OnRtnDeferDeliveryQuot(CThostDeferDeliveryQuot* pQuot);

	///��������Ӧ��
	virtual void OnRspSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast) ;

	///ȡ����������Ӧ��
	virtual void OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);

private:
	CThostFtdcMdApi* const m_pApi;
};

#endif