
#include <stdio.h>
//#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include "TradeSpi.h"
#include "MdSpi.h"
#include "GetParam.h"

//#include <sys\timeb.h>
//#include "../CDTime/CDTime.h"

#ifdef WIN32
	#include <windows.h>
	void sgit_Sleep(int seconds)
	{
		Sleep(seconds*1000);
	}

#else
	#include "unistd.h"
	void sgit_Sleep(int seconds)
	{
		::sleep(seconds);
	}
#endif // !WIN3

int requestID = 0;
int GetRequsetID(){return ++requestID;}

int ReqQrySettlementInfo( CThostFtdcTraderApi* pTradeApi);
int ReqOrderInsert( CThostFtdcTraderApi* pTradeApi,long OrderRef);
int ReqOrderAction( CThostFtdcTraderApi* pTradeApi);
int ReqQryTrade( CThostFtdcTraderApi* pTradeApi);
int ReqQryOrder( CThostFtdcTraderApi* pTradeApi);
int ReqQryInvestorPosition( CThostFtdcTraderApi* pTradeApi);
int ReqQryInstrumentMarginRate( CThostFtdcTraderApi* pTradeApi);
int ReqQryInstrumentCommissionRate( CThostFtdcTraderApi* pTradeApi);

int ReqQryPositionDetail(CThostFtdcTraderApi* pTradeApi);
int ReqQrySettlementConfirm(CThostFtdcTraderApi* pTradeApi);
int ReqQryNotice(CThostFtdcTraderApi* pTradeApi);
int ReqQryComPositionDetail(CThostFtdcTraderApi* pTradeApi);
int ReqQryTradeParam(CThostFtdcTraderApi* pTradeApi);

int Subquot(CThostFtdcMdApi* pMdApi);
int UnsubQuot(CThostFtdcMdApi* pMdApi);

int ReqqryInstrument(CThostFtdcTraderApi* pTradeApi);

int ReqqryInvestor(CThostFtdcTraderApi* pTradeApi);

int ReqLogout(CThostFtdcTraderApi* pTradeApi,char* pUserID);
//int ReqQryTradeParam(CThostFtdcTraderApi* pTradeApi);

int ReqQryDeferFeeRate(CThostFtdcTraderApi* pTradeApi);
int reqQryDeferMidTrade(CThostFtdcTraderApi* pTradeApi);

CThostFtdcReqUserLoginField gloginField;

int main(int argc,char** argv)
{
	//��ȡ��½����
	memset(&gloginField,0,sizeof(gloginField));
	GetLoginField(gloginField);

	//��������api����
	CThostFtdcTraderApi* pTradeApi = CThostFtdcTraderApi::CreateFtdcTraderApi("TradeFlow/");
	//��������api����
	CThostFtdcMdApi* pMdApi = CThostFtdcMdApi::CreateFtdcMdApi("QuoteFlow/");
	
	//����������Ӧ����
	CTradeSpi tradeSpi(pTradeApi);
	//����������Ӧ����
	CMdSpi mdSpi(pMdApi);

	//ע�ύ����Ӧ����
	pTradeApi->RegisterSpi(&tradeSpi);
	pTradeApi->SubscribePrivateTopic(THOST_TERT_RESUME);
	//pTradeApi->IsReviveNtyCapital(0);
	pTradeApi->InitLog(0);
	//ע��������Ӧ����
	pMdApi->RegisterSpi(&mdSpi);

	//��ȡip
	char tradeIp[36];
	char quotIp[36];
	memset(tradeIp,0,sizeof(tradeIp));
	memset(quotIp,0,sizeof(quotIp));
	if(GetIpField(tradeIp,quotIp))
	{
		printf("param.xml��server���ô���\n");
		system("pause");
		return 0;
	}

	//ע�ύ�׷����ַ
	pTradeApi->RegisterFront(tradeIp);
	//ע����������ַ
	pMdApi->RegisterFront(quotIp);
	//�Ƿ�����ʽ�����
	pTradeApi->IsReciveNtyCapital(0);
	//�Ƿ��ӡ��־
	pTradeApi->InitLog(1);
	//���ӳ�ʼ��
	pTradeApi->Init();
	pMdApi->Init();
	//��ʼ����ȴ�����֪ͨ����OnFrontConnected()���ص����͵�¼����

	while(1)
	{
		if(tradeSpi.bConnected)//δ��¼�ɹ�
		{
			switch(getchar())
			{
			case '.':
				{
					printf("************\n");
					printf("q/Q-exit\n");
					printf("1-OrderInsert\n");
					printf("2-OrderAction\n");
					printf("3-qryOrder\n");
					printf("4-qryTrade\n");
					printf("5-qryPosition\n");
					printf("6-QryInstrumentMarginRate\n");
					printf("7-QryInstrumentCommissionRate\n");

					printf("8-ReqQryPositionDetail\n");
					printf("9-ReqQrySettlementConfirm\n");
					printf("a-ReqQryNotice\n");
					printf("b-ReqQryComPositionDetail\n");
					printf("c-ReqQryTradeParam\n");

					printf("d-SubQuot\n");
					printf("e-UnSubQuot\n");

					printf("f-ReqQryInstrument\n");
					printf("g-ReqqryInvestor\n");

					printf("h-ReqLogout\n");
					printf("i-ReqQryDeferFeeRate\n");
					printf("j-ReqQryDeferMidTrade\n");
					//printf("k-ReqQryTradeParam\n");
					printf("************\n");

				}
				break;
			case 'q':
			case 'Q':
				pMdApi->Release();
				pTradeApi->Release();
				return 0;
			case '1':
				ReqOrderInsert(pTradeApi,++tradeSpi.OrderRef);
				break;
			case '2':
				ReqOrderAction(pTradeApi);
				break;
			case '3':
				ReqQryOrder(pTradeApi);
				break;
			case '4':
				ReqQryTrade(pTradeApi);
				break;
			case '5':
				ReqQryInvestorPosition(pTradeApi);
				break;
			case '6':
				ReqQryInstrumentMarginRate(pTradeApi);
				break;
			case '7':
				ReqQryInstrumentCommissionRate(pTradeApi);
				break;
			case '8':
				ReqQryPositionDetail( pTradeApi);
				break;
			case '9':
				ReqQrySettlementConfirm( pTradeApi);
				break;
			case 'a':
				ReqQryNotice( pTradeApi);
				break;
			case 'b':
				ReqQryComPositionDetail( pTradeApi);
				break;
			case 'c':
				ReqQryTradeParam(pTradeApi);
				break;
			case 'd':
				Subquot(pMdApi);
				break;
			case 'e':
				UnsubQuot(pMdApi);
				break;
			case 'f':
				ReqqryInstrument(pTradeApi);
				break;
			case 'g':
				ReqqryInvestor(pTradeApi);
				break;
			case 'h':
				ReqLogout(pTradeApi,gloginField.UserID);
				break;
			case 'i':
				ReqQryDeferFeeRate(pTradeApi);
				break;
			case 'j':
				reqQryDeferMidTrade(pTradeApi);
				break;
			//case 'k':
			//	ReqQryTradeParam(pTradeApi);
			//	break;
			default:
				break;
			}
		}
		sgit_Sleep(3);
	}
}

int ReqQrySettlementInfo(CThostFtdcTraderApi* pTradeApi)
{
	printf("������ȷ��...\n");
	
	fstech::CThostFtdcSettlementInfoConfirmField settlementInfoConfirm;
	memset(&settlementInfoConfirm,0,sizeof(settlementInfoConfirm));
	return pTradeApi->ReqSettlementInfoConfirm(&settlementInfoConfirm,GetRequsetID());
}

int ReqOrderInsert( CThostFtdcTraderApi* pTradeApi,long iOrderRef)
{
	printf("����...\n");

	CThostFtdcInputOrderField InputOrder;
	memset(&InputOrder,0,sizeof(InputOrder));
	//��Ա��
	strncpy(InputOrder.BrokerID,gloginField.BrokerID,sizeof(InputOrder.BrokerID));
	//����Ա
	strncpy(InputOrder.UserID,gloginField.UserID,sizeof(InputOrder.UserID));
	//�������ļ��л�ȡ�ʽ��˺�,��Լ����,�۸�,����,����,Ͷ����
	GetOrderInsertField(InputOrder);
	//
	TInvestor& Investor = gExchange2Investor.find(reinterpret_cast<TInvestorKey&>(InputOrder.ExchangeID))->second;
	//�ʽ��˺�
	strncpy(InputOrder.InvestorID,Investor.investorid,sizeof(InputOrder.InvestorID));
	//����
	InputOrder.Direction = (InputOrder.Direction == 'B' || InputOrder.Direction == 'b') ? THOST_FTDC_D_Buy : THOST_FTDC_D_Sell;
	//��ƽ
	InputOrder.CombOffsetFlag[0] = (InputOrder.CombOffsetFlag[0] == 'C' || InputOrder.CombOffsetFlag[0] == 'c') ? THOST_FTDC_OF_Close : THOST_FTDC_OF_Open;
	//���ر����ţ���ͬһ������Ա��˵��������յ����±����ı��ر����ű���ȸý���Աǰһ�ʱ����ı��ر����Ŵ󣨰��ַ����Ƚϣ�
	sprintf(InputOrder.OrderRef,"%012ld",iOrderRef);//���ر�����
	//Ͷ��
	InputOrder.CombHedgeFlag[0] = THOST_FTDC_HF_Speculation;
	///��С�ɽ���
	InputOrder.MinVolume = 1;
	//�۸�����
	InputOrder.OrderPriceType = THOST_FTDC_OPT_LimitPrice;
	//��ͨ���� TimeCondition��VolumeCondition ����
	///��Ч������
	InputOrder.TimeCondition = THOST_FTDC_TC_GFD;//������Ч
	///�ɽ�������
	InputOrder.VolumeCondition = THOST_FTDC_VC_AV;//�κ�����
	////FOK���� TimeCondition��VolumeCondition ����
	/////��Ч������
	//InputOrder.TimeCondition = THOST_FTDC_TC_IOC;//������ɣ�������
	/////�ɽ�������
	//InputOrder.VolumeCondition = THOST_FTDC_VC_CV;//ȫ������
	////FAK���� TimeCondition��VolumeCondition ����
	/////��Ч������
	//InputOrder.TimeCondition = THOST_FTDC_TC_IOC;//������ɣ�������
	/////�ɽ�������
	//InputOrder.VolumeCondition = THOST_FTDC_VC_AV;//�κ�����

	///GTD����
	//sprintf(InputOrder.GTDDate, "%s", pTradeDate);
	///��������
	InputOrder.ContingentCondition = THOST_FTDC_CC_Immediately;//����
	///ֹ���
	InputOrder.StopPrice = 0.0;
	///ǿƽԭ��
	InputOrder.ForceCloseReason = THOST_FTDC_FCC_NotForceClose;//��ǿƽ
	///�Զ������־
	InputOrder.IsAutoSuspend = 0;
	///ҵ��Ԫ
	InputOrder.BusinessUnit[0] = 0;
	///������
	InputOrder.RequestID = GetRequsetID();
	///�û�ǿƽ��־
	InputOrder.UserForceClose = 0;
	///��������־
	InputOrder.IsSwapOrder = 0;
	//���ױ��룬���Ӹ�Ƶ��̨ʱ��Ҫ��д
	strncpy(InputOrder.ClientID,Investor.clientid,sizeof(InputOrder.ClientID));

	TnsertOrder2LocalOrderMap(&InputOrder);
	//hrTime.StartTimer();
	int ret = pTradeApi->ReqOrderInsert(&InputOrder,InputOrder.RequestID);
	//gtime_map[gtime_map.size()].time0 = hrTime.StopTimer();
	printf(0 == ret ? "���������ͳɹ�!\n" : "����������ʧ��!\n");
	return ret;
}

int ReqOrderAction(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcOrderField* pOrder = nullptr;
	for(auto it = gLocalOrderMap.begin(); it != gLocalOrderMap.end(); ++it)
	{
		TThostFtdcOrderStatusType	OrderStatus = it->second.value.OrderStatus;
		if(THOST_FTDC_OST_NoTradeQueueing == OrderStatus || THOST_FTDC_OST_PartTradedQueueing == OrderStatus || OrderStatus >= THOST_FTDC_OST_Unknown)
		{
			pOrder = &it->second.value;
			break;
		}
	}
	if(pOrder == nullptr) return 0;

	CThostFtdcInputOrderActionField inputOrderAction;
	memset(&inputOrderAction,0,sizeof(inputOrderAction));
	memcpy(inputOrderAction.BrokerID,pOrder->BrokerID,sizeof(inputOrderAction.BrokerID));
	memcpy(inputOrderAction.ExchangeID,pOrder->ExchangeID,sizeof(inputOrderAction.ExchangeID));
	memcpy(inputOrderAction.OrderSysID,pOrder->OrderSysID,sizeof(inputOrderAction.OrderSysID));
	memcpy(inputOrderAction.UserID,pOrder->UserID,sizeof(inputOrderAction.UserID));
	memcpy(inputOrderAction.OrderRef,pOrder->OrderRef,sizeof(inputOrderAction.OrderRef));
	memcpy(inputOrderAction.InstrumentID,pOrder->InstrumentID,sizeof(inputOrderAction.InstrumentID));
	inputOrderAction.ActionFlag = THOST_FTDC_AF_Delete;
	//���Ӹ�Ƶ��̨ʱ��Ҫ��дClientID�ֶ�
	strcpy(inputOrderAction.ClientID,pOrder->ClientID);
	inputOrderAction.RequestID = GetRequsetID();
	int ret = pTradeApi->ReqOrderAction(&inputOrderAction,inputOrderAction.RequestID);
	printf(0 == ret ? "���������ͳɹ�!\n" : "����������ʧ��!\n");
	return ret;
}

int ReqQryTrade( CThostFtdcTraderApi* pTradeApi)
{
	printf("�ɽ���ѯ...\n");
	CThostFtdcQryTradeField QryTrade;
	memset(&QryTrade,0,sizeof(QryTrade));
	//strncpy_s(QryTrade.BrokerID,pBrokerID,sizeof(QryTrade.BrokerID));
	//strncpy_s(QryTrade.InvestorID ,pInvestorID,sizeof(QryTrade.InvestorID));
	//strncpy_s(QryTrade.InstrumentID,"IF1509",sizeof(QryTrade.InstrumentID));
	//strncpy_s(QryTrade.ExchangeID,pExchang,sizeof(QryTrade.ExchangeID));
	////strncpy_s(QryTrade.TradeID,pTradeDate,sizeof(QryTrade.TradeID));
	//strncpy_s(QryTrade.TradeTimeStart,"",sizeof(QryTrade.TradeTimeStart));
	//strncpy_s(QryTrade.TradeTimeEnd,"",sizeof(QryTrade.TradeTimeEnd));
	return pTradeApi->ReqQryTrade(&QryTrade,GetRequsetID());	
}

int ReqQryOrder( CThostFtdcTraderApi* pTradeApi)
{
	printf("ί�в�ѯ...\n");

	CThostFtdcQryOrderField QryOrder;
	memset(&QryOrder,0,sizeof(QryOrder));
	//����½ʱ��д�ı���һ��,���������������е�brokerID����"";
	strncpy(QryOrder.BrokerID,"",sizeof(QryOrder.BrokerID));
	//strncpy_s(QryOrder.InstrumentID,pInstrument,sizeof(QryOrder.InstrumentID));
	//strncpy_s(QryOrder.InvestorID,pInvestorID,sizeof(QryOrder.InvestorID));
	//strncpy_s(QryOrder.ExchangeID ,pExchang,sizeof(QryOrder.ExchangeID));
	//strncpy_s(QryOrder.InsertTimeStart,"",sizeof(QryOrder.InsertTimeStart));
	//strncpy_s(QryOrder.InsertTimeEnd,"",sizeof(QryOrder.InsertTimeEnd));
	return pTradeApi->ReqQryOrder(&QryOrder,GetRequsetID());
}

int ReqQryInvestorPosition( CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryInvestorPositionField QryInvestorPosition;
	memset(&QryInvestorPosition,0,sizeof(QryInvestorPosition));
	//strncpy_s(QryInvestorPosition.InstrumentID,"Ag(T+D)",sizeof(QryInvestorPosition.InstrumentID));
	//strncpy_s(QryInvestorPosition.InvestorID,"0800031",sizeof(QryInvestorPosition.InvestorID));
	//strncpy_s(QryInvestorPosition.BrokerID,pBrokerID,sizeof(QryInvestorPosition.BrokerID));
	return pTradeApi->ReqQryInvestorPosition(&QryInvestorPosition,GetRequsetID());
}

int ReqQryInstrumentMarginRate( CThostFtdcTraderApi* pTradeApi)
{
	///�����ѯ��Լ��֤����
	printf("�����ѯ��Լ��֤����...\n");
	CThostFtdcQryInstrumentMarginRateField QryInstrumentMarginRate;
	memset(&QryInstrumentMarginRate,0,sizeof(CThostFtdcQryInstrumentMarginRateField));
	strncpy(QryInstrumentMarginRate.InvestorID,"0600032",sizeof(QryInstrumentMarginRate.InvestorID));
//	strncpy(QryInstrumentMarginRate.InstrumentID,"TT1603",sizeof(QryInstrumentMarginRate.InstrumentID));
//	pTradeApi->ReqQryInstrumentMarginRate(&QryInstrumentMarginRate,GetRequsetID());

	//memset(&QryInstrumentMarginRate,0,sizeof(CThostFtdcQryInstrumentMarginRateField));
	//strncpy(QryInstrumentMarginRate.InvestorID,"0600032",sizeof(QryInstrumentMarginRate.InvestorID));
	//strncpy(QryInstrumentMarginRate.InstrumentID,"iAu99.99",sizeof(QryInstrumentMarginRate.InstrumentID));

	//for(int i = 0;i < 200; ++i)
	//{
	//	pTradeApi->ReqQryInstrumentMarginRate(&QryInstrumentMarginRate,GetRequsetID());
	//}
	return pTradeApi->ReqQryInstrumentMarginRate(&QryInstrumentMarginRate,GetRequsetID());
}

int ReqQryInstrumentCommissionRate( CThostFtdcTraderApi* pTradeApi)
{
	//�����ѯ��Լ��������
	printf("�����ѯ��Լ��������...\n");
	CThostFtdcQryInstrumentCommissionRateField QryInstrumentCommissionRate;
	memset(&QryInstrumentCommissionRate,0,sizeof(CThostFtdcQryInstrumentCommissionRateField));
	strncpy(QryInstrumentCommissionRate.InvestorID,"0600032",sizeof("0600032"));
	//strncpy(QryInstrumentCommissionRate.InstrumentID,"Au(T+N1)",sizeof(QryInstrumentCommissionRate.InstrumentID));
	/*strncpy_s(QryInstrumentCommissionRate.BrokerID,pBrokerID,sizeof(QryInstrumentCommissionRate.BrokerID));
	strncpy_s(QryInstrumentCommissionRate.InvestorID,pInvestorID,sizeof(QryInstrumentCommissionRate.InvestorID));
	strncpy_s(QryInstrumentCommissionRate.InstrumentID,pInstrument,sizeof(QryInstrumentCommissionRate.InstrumentID));*/
	return pTradeApi->ReqQryInstrumentCommissionRate(&QryInstrumentCommissionRate,GetRequsetID());
}

int ReqQryPositionDetail(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryInvestorPositionDetailField req;
	memset(&req,0,sizeof(req));
	return pTradeApi->ReqQryInvestorPositionDetail(&req,GetRequsetID());
}

int ReqQrySettlementConfirm(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQrySettlementInfoConfirmField req;
	memset(&req,0,sizeof(req));
	return pTradeApi->ReqQrySettlementInfoConfirm(&req,GetRequsetID());
}

int ReqQryNotice(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryNoticeField req;
	memset(&req,0,sizeof(req));
	return pTradeApi->ReqQryNotice(&req,GetRequsetID());
}

int ReqQryComPositionDetail(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryInvestorPositionCombineDetailField req;
	memset(&req,0,sizeof(req));
	return pTradeApi->ReqQryInvestorPositionCombineDetail(&req,GetRequsetID());
}

int ReqQryTradeParam(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryBrokerTradingParamsField req;
	memset(&req,0,sizeof(req));
	return pTradeApi->ReqQryBrokerTradingParams(&req,GetRequsetID());
}

int Subquot(CThostFtdcMdApi* pMdApi)
{
	char * pInstrument [] = {
		"Ag(T+D)",
		"Au(T+D)"
	};
	return pMdApi->SubscribeMarketData(pInstrument,2);
}

int UnsubQuot(CThostFtdcMdApi* pMdApi)
{
	char * pInstrument [] = {
		"Ag(T+D)",
		"Au(T+D)"
	};
	return pMdApi->UnSubscribeMarketData(pInstrument,2);
}

int ReqqryInstrument(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryInstrumentField QryInstrument;
	memset(&QryInstrument,0,sizeof(QryInstrument));

	return pTradeApi->ReqQryInstrument(&QryInstrument,GetRequsetID());
}

int ReqqryInvestor(CThostFtdcTraderApi* pTradeApi)
{
	CThostFtdcQryInvestorField QryInstrument;
	memset(&QryInstrument,0,sizeof(QryInstrument));

	return pTradeApi->ReqQryInvestor(&QryInstrument,GetRequsetID());
}

int ReqLogout(CThostFtdcTraderApi* pTradeApi,char* pUserID)
{
	CThostFtdcUserLogoutField req;
	memset (&req,0,sizeof(req));
	strncpy(req.UserID,pUserID,sizeof(req.UserID));;
	return pTradeApi->ReqUserLogout(&req,0);
}

int ReqQryDeferFeeRate(CThostFtdcTraderApi* pTradeApi)
{
	printf("���ӷѲ�ѯ.../n");
	CThostDeferFeeRateField reqFld;
	memset(&reqFld,0,sizeof(reqFld));
	return pTradeApi->ReqQryDeferFeeRate(&reqFld,GetRequsetID());
}

int reqQryDeferMidTrade(CThostFtdcTraderApi* pTradeApi)
{
	printf("���ӽ���/�����ֳɽ���ѯ.../n");
	CThostFtdcQryTradeField QryTrade;
	memset(&QryTrade,0,sizeof(QryTrade));
	return pTradeApi->ReqQryDeferMidAppTrade(&QryTrade,GetRequsetID());
}
