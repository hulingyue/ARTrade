#include "GetParam.h"
#include <string.h>
#include "../xml/tinyxml2.h"

using namespace tinyxml2;

int GetIpField(char* pTradeIp,char* pQuotIp)
{
	XMLDocument doc;
	if(XML_SUCCESS != doc.LoadFile("param.xml"))
		return -1;
	XMLElement* pServer = doc.RootElement();
	if(0 == pServer)
		return -2;
	pServer = pServer->FirstChildElement("server");
	if(0 == pServer)
		return -3;

	XMLElement *pTip = pServer->FirstChildElement("tradeServer");
	if(0 != pTip)
	{
		const char* pText = pTip->GetText();
		sprintf(pTradeIp,"%s",0 == pText ? "" : pText);
	}

	pTip = pServer->FirstChildElement("quoteServer");
	if(0 != pTip)
	{
		const char* pText = pTip->GetText();
		sprintf(pQuotIp,"%s",0 == pText ? "" : pText);
	}
		
	return 0;
}

int GetLoginField(fstech::CThostFtdcReqUserLoginField& reqLoginField)
{
	XMLDocument doc;
	if(XML_SUCCESS != doc.LoadFile("param.xml"))
		return -1;		
	XMLElement* pLogin = doc.RootElement();
	if(0 == pLogin)
		return -2;
	XMLElement* pElement = pLogin->FirstChildElement("brokerID");
	if(0 != pElement)
	{
		const char* pText = pElement->GetText();
		strcpy(reqLoginField.BrokerID,0 == pText ? "" : pText);
	}
	pLogin = pLogin->FirstChildElement("login");
	if(0 == pLogin)
		return -3;

	pElement = pLogin->FirstChildElement("userID");
	if(0 != pElement)
	{
		const char* pText = pElement->GetText();
		strcpy(reqLoginField.UserID,0 == pText ? "" : pText);
	}

	pElement = pLogin->FirstChildElement("pwd");
	if(0 != pElement)
	{
		const char* pText = pElement->GetText();
		strcpy(reqLoginField.Password,0 == pText ? "" : pText);
	}

	pElement = pLogin->FirstChildElement("appID");
	if(0 != pElement)
	{
		const char* pText = pElement->GetText();
		strcpy(reqLoginField.AppID,0 == pText ? "" : pText);
	}

	pElement = pLogin->FirstChildElement("authCode");
	if(0 != pElement)
	{
		const char* pText = pElement->GetText();
		strcpy(reqLoginField.AuthCode,0 == pText ? "" : pText);
	}

	return 0;
}

int GetOrderInsertField(fstech::CThostFtdcInputOrderField& ReqOrderField)
{
	XMLDocument doc;
	if(XML_SUCCESS != doc.LoadFile("param.xml"))
		return -1;
	XMLElement* pSendOrder = doc.RootElement();
	if(0 == pSendOrder)
		return -2;
	pSendOrder = pSendOrder->FirstChildElement("sendOrder");
	if(0== pSendOrder)
		return -3;
	//����������
	XMLElement* pItem = pSendOrder->FirstChildElement("exchange");
	if(0 != pItem)
	{
		const char* pText = pItem->GetText();
		if(0 != pText)
			strcpy(ReqOrderField.ExchangeID,pText);
	}
	//��Լ����
	pItem = pSendOrder->FirstChildElement("instrument");
	if(0 != pItem)
	{
		const char* pText = pItem->GetText();
		if(0 != pText)
			strcpy(ReqOrderField.InstrumentID,pText);
	}
	//ί�м�
	pItem = pSendOrder->FirstChildElement("price");
	if(0 != pItem)
	{
		const char* pText = pItem->GetText();
		ReqOrderField.LimitPrice = atof(pText);
	}
	//ί����
	pItem = pSendOrder->FirstChildElement("volume");
	if(0 != pItem)
	{
		const char* pText = pItem->GetText();
		ReqOrderField.VolumeTotalOriginal = atoi(pText);
	}
	pItem = pSendOrder->FirstChildElement("bsFlag");
	if(0 != pItem)
	{
		const char* pText = pItem->GetText();
		if(0 != pText)
			ReqOrderField.Direction = *pText;
	}
	pItem = pSendOrder->FirstChildElement("offsetFlag");
	if(0 != pItem)
	{
		const char* pText = pItem->GetText();
		if(0 != pText)
			ReqOrderField.CombOffsetFlag[0] = *pText;
	}

	return 0;
}


int WriteTradecode(fstech::CThostFtdcTradingCodeField* pTradingCodeField)
{
	if(0 == pTradingCodeField)
		return -1;
	XMLDocument doc;
	if(XML_SUCCESS != doc.LoadFile("param.xml"))
		return -2;

	XMLElement* pRoot = doc.RootElement();
	if(0 != pRoot)
	{
		XMLElement* pTradeCode = pRoot->FirstChildElement("tradecode");
		if(pTradeCode == 0)
		{
			pTradeCode = doc.NewElement("tradecode");
			pRoot->InsertEndChild(pTradeCode);
		}
		XMLElement* pItem = pTradeCode->FirstChildElement("item");
		while (0 != pItem)
		{
			if(0 == strcmp(pTradingCodeField->ClientID,pItem->Attribute("clientid")) && strcmp(pTradingCodeField->ExchangeID,pItem->Attribute("exchangid")) == 0)
				return 0;
			pItem = pItem->NextSiblingElement();
		}

		pItem = doc.NewElement("item");
		pTradeCode->InsertEndChild(pItem);

		pItem->SetAttribute("investorid",pTradingCodeField->InvestorID);
		pItem->SetAttribute("exchangid",pTradingCodeField->ExchangeID);
		pItem->SetAttribute("clientid",pTradingCodeField->ClientID);

		doc.SaveFile("param.xml");
	}

	return 0;
}

