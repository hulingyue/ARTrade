#ifndef _DQK_TIME_H_20160913
#define _DQK_TIME_H_20160913

#include<stdio.h>
#include<string.h>
#include <list>
#include <map>

struct TTimeList 
{
	double time0;
	double time1;
	double time2;
	double time3;
	double time4;
	double time5;
	double time6;
	double time7;
	double time8;
	double time9;
};
typedef std::map<int ,TTimeList> TTimeList_map;
extern TTimeList_map gtime_map;

#ifdef _WIN32
	#include <windows.h>

	class LGHRTimer_d 
	{
	public:

		LGHRTimer_d(void)
		{
			frequency = this->GetFrequency()/1000;//΢��	
		}

		double GetFrequency(void)
		{
			LARGE_INTEGER proc_freq;
			::QueryPerformanceFrequency(&proc_freq);

			//if (!::QueryPerformanceFrequency(&proc_freq)) throw Exception(TEXT("QueryPerformanceFrequency() failed"));

			return proc_freq.QuadPart;

		}

		void StartTimer(void) 
		{
			DWORD oldmask = ::SetThreadAffinityMask(::GetCurrentThread(), 0);

			::QueryPerformanceCounter(&start);

			::SetThreadAffinityMask(::GetCurrentThread(), oldmask);

		}

		double StopTimer(void)
		{
			DWORD oldmask = ::SetThreadAffinityMask(::GetCurrentThread(), 0);

			::QueryPerformanceCounter(&stop);

			::SetThreadAffinityMask(::GetCurrentThread(), oldmask);

			return ((stop.QuadPart - start.QuadPart) / frequency);

		}

		//double GetTimer(void)
		//{
		//	DWORD oldmask = ::SetThreadAffinityMask(::GetCurrentThread(), 0);

		//	::QueryPerformanceCounter(&get);

		//	::SetThreadAffinityMask(::GetCurrentThread(), oldmask);

		//	return ((get.QuadPart) / frequency);

		//}
	private:

		LARGE_INTEGER start;
		LARGE_INTEGER stop;
		LARGE_INTEGER get;
		double frequency;	
		//..
	};
#else
	#include "unistd.h"
	class LGHRTimer_d 
	{
	private:
		struct timeval m_tvStart;
	public:
		HRTimer(void){};		
		void StartTimer(void) 
		{
			gettimeofday(&m_tvStart, NULL);
		};
		long GetMilliSeconds(void)
		{
			struct timeval tv;
			gettimeofday(&tv, NULL);
			return tv.sec * 1000 + tv.usec;
		};
	};
#endif

extern LGHRTimer_d hrTime;

#endif
