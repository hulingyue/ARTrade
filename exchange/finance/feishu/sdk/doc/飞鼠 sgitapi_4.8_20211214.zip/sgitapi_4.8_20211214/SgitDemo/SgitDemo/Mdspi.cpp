#include "MdSpi.h"
#include "string.h"
#include "../log/log.h"

#ifdef WIN32
	//#ifdef NDEBUG
		#pragma comment(lib,"../../lib/sgitquotapi.lib")
	//#else
	//	#pragma comment(lib,"../../lib/sgitquotapid.lib")
	//#endif
#endif

extern CThostFtdcReqUserLoginField gloginField;

CMdSpi::CMdSpi(CThostFtdcMdApi * pMdApi) : m_pApi(pMdApi)
{
}

CMdSpi::~CMdSpi()
{
}

void CMdSpi::OnFrontConnected()
{
	int ret = m_pApi->ReqUserLogin(&gloginField,0);
	SgitDemo_log::CLogApi log;
	log<<"�����¼���ͽ����"<< ret << '\n';
}

void CMdSpi::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
// bConnected = false;
	SgitDemo_log::CLogApi LOG;
	LOG<<"�����¼������Ӧ-OnRspUserLogin-"<<nRequestID<<",bIsLast-"<<bIsLast<<"\n";
	if(NULL != pRspInfo && 0 != pRspInfo->ErrorID)
	{
		printf("pRspInfo msg%d - %s",pRspInfo->ErrorID,pRspInfo->ErrorMsg);
		LOG<<"OnRspUserLogin:errcode-"<<pRspInfo->ErrorID<<",msg-"<<pRspInfo->ErrorMsg<<"\n";
	}
	else
	{
		if(pRspUserLogin)
		{

		}

		if(bIsLast )
		{
			printf("��¼�������ɹ�\n\n");
			LOG<<"��¼�������ɹ�\n";
			char * pInstrumnet[] = 
			{
				/* "Ag(T+D)",
				"Ag(T+D)"*/
				"all"
			};
			m_pApi->SubscribeMarketData(pInstrumnet,1);
		}
	}
}

 //int k = 0;
 void CMdSpi::OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData) 
 {
	 SgitDemo_log::CLogApi LOG;
	 //printf("����֪ͨ:%d--%s\n",++k,pDepthMarketData->InstrumentID);
	 LOG<<"OnRtnDepthMarketData//����֪ͨ:"
		 <<"TradingDay//������="<<pDepthMarketData->TradingDay
		 <<",InstrumentID//��Լ����="<<pDepthMarketData->	InstrumentID
		 <<",ExchangeID//����������="<<pDepthMarketData->ExchangeID
		 <<",ExchangeInstID//��Լ�ڽ������Ĵ���="<<pDepthMarketData->ExchangeInstID
		 <<",LastPrice//���¼�="<<pDepthMarketData->LastPrice
		 <<",PreSettlementPrice//�ϴν����="<<pDepthMarketData->PreSettlementPrice
		 <<",PreClosePrice������="<<pDepthMarketData->PreClosePrice
		 <<",PreOpenInterest��ֲ���="<<pDepthMarketData->PreOpenInterest
		 <<",OpenPrice//����="<<pDepthMarketData->OpenPrice
		 <<",HighestPrice/��߼�="<<pDepthMarketData->	HighestPrice
		 <<",LowestPrice//��ͼ�="<<pDepthMarketData->LowestPrice
		 <<",Volume//����="<<pDepthMarketData->Volume
		 <<",Turnover//�ɽ����="<<pDepthMarketData->	Turnover
		 <<",OpenInterest//�ֲ���="<<pDepthMarketData->	OpenInterest
		 <<",ClosePrice//������="<<pDepthMarketData->ClosePrice
		 <<",SettlementPrice//���ν����="<<pDepthMarketData->SettlementPrice
		 <<",UpperLimitPrice//��ͣ���="<<pDepthMarketData->UpperLimitPrice
		 <<",LowerLimitPrice//��ͣ���="<<pDepthMarketData->LowerLimitPrice
		 <<",PreDelta//����ʵ��="<<pDepthMarketData->	PreDelta
		 <<",CurrDelta//����ʵ��="<<pDepthMarketData->CurrDelta
		 <<",UpdateTime//����޸�ʱ��="<<pDepthMarketData->UpdateTime
		 <<",UpdateMillisec//����޸ĺ���="<<pDepthMarketData->UpdateMillisec
		 <<",BidPrice1//�����һ="<<pDepthMarketData->BidPrice1
		 <<",BidVolume1//������һ="<<pDepthMarketData->BidVolume1
		 <<",AskPrice1="<<pDepthMarketData->AskPrice1
		 <<",AskVolume1="<<pDepthMarketData->AskVolume1
		 <<",BidPrice2="<<pDepthMarketData->BidPrice2
		 <<",BidVolume2="<<pDepthMarketData->BidVolume2
		 <<",AskPrice2="<<pDepthMarketData->AskPrice2
		 <<",AskVolume2="<<pDepthMarketData->AskVolume2
		 <<",BidPrice3="<<pDepthMarketData->BidPrice3
		 <<",BidVolume3="<<pDepthMarketData->BidVolume3
		 <<",AskPrice3="<<pDepthMarketData->AskPrice3
		 <<",AskVolume3="<<pDepthMarketData->AskVolume3
		 <<",BidPrice4="<<pDepthMarketData->BidPrice4
		 <<",BidVolume4="<<pDepthMarketData->BidVolume4
		 <<",AskPrice4="<<pDepthMarketData->AskPrice4
		 <<",AskVolume4="<<pDepthMarketData->AskVolume4
		 <<",BidPrice5="<<pDepthMarketData->BidPrice5
		 <<",BidVolume5="<<pDepthMarketData->BidVolume5
		 <<",AskPrice5="<<pDepthMarketData->AskPrice5
		 <<",AskVolume5="<<pDepthMarketData->AskVolume5
		 <<",AveragePrice//���վ���="<<pDepthMarketData->AveragePrice
		 <<",ActionDay//ҵ������="<<pDepthMarketData->ActionDay
		 <<"\n";

	 	//	char * pInstrumnet[1]; 
			//pInstrumnet[0] = pDepthMarketData->InstrumentID;
			//m_pApi->SubscribeMarketData(pInstrumnet,1);

	 return;
 }


 void CMdSpi::OnRtnDeferDeliveryQuot(CThostDeferDeliveryQuot* pQuot)
 {
	 printf("OnRtnDeferDeliveryQuot\n");
	 SgitDemo_log::CLogApi LOG;
	 LOG<<"OnRtnDeferDeliveryQuot-"<<(UINT_PTR)pQuot<<"\n";
	 if(NULL != pQuot)
	 {
		 LOG<<pQuot->InstrumentID<<","
			 <<pQuot->AskVolume<<","
			 <<pQuot->BidVolume<<","
			 <<pQuot->MidAskVolume<<","
			 <<pQuot->MidBidVolume<<"\n"
			 ;
	 }
 }

 ///��������Ӧ��
 void CMdSpi::OnRspSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
 {
	 SgitDemo_log::CLogApi LOG;
	 LOG<<"OnRspSubMarketData-"<<nRequestID<<",blast-"<<bIsLast<<"\n";
	 if(NULL != pRspInfo)
	 {
		 LOG<<"pRspInfo:errorid="<<pRspInfo->ErrorID<<
			 ",errorMsg="<<pRspInfo->ErrorMsg<<"\n"
			 ;
	 }
	 if(NULL != pSpecificInstrument)
		 LOG<<"pSpecificInstrument:"<<pSpecificInstrument->InstrumentID<<"\n";
 }

 ///ȡ����������Ӧ��
 void CMdSpi::OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
 {
	 SgitDemo_log::CLogApi LOG;
	 LOG<<"OnRspUnSubMarketData-"<<nRequestID<<",blast-"<<bIsLast<<"\n";
	 if(NULL != pRspInfo)
	 {
		 LOG<<"pRspInfo:errorid="<<pRspInfo->ErrorID<<
			 ",errorMsg="<<pRspInfo->ErrorMsg<<"\n"
			 ;
	 }
	 if(NULL != pSpecificInstrument)
		 LOG<<"pSpecificInstrument:"<<pSpecificInstrument->InstrumentID<<"\n";
 }
